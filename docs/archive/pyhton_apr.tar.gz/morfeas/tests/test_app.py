import app

# Placeholder, can be deleted
def test_index_no_arguments_returns_morfeas():
    result = app.index()
    assert result == "Morfeas"